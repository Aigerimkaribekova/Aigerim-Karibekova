$(document).ready(function registration()){
    var name= $("#t1").value;
    var email= $("#t2").value;
    var uname= $("#t3").value;
    var pwd= $("#t4").value;
    var cpwd= $("#t5").value;

        //email id expression code
    var pwd_expression = /^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-])/;
    var letters = /^[A-Za-z]+$/;
    var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;

    if($("#t1").value=='')
    {
      alert('Please enter your name');
    }
    else if(! /^[A-Za-z]+$/.test($("#t1").value))
    {
      alert('Name field required only alphabet characters');
    }
    else if($("#t2").value=='')
    {
      alert('Please enter your user email id');
    }
    else if (!/^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/.test($("#t2").value))
    {
      alert('Invalid email');
    }
    else if($("#t3").value=='')
    {
      alert('Please enter the user name.');
    }
    else if(! /^[A-Za-z]+$/.test($("#t3").value))
    {
      alert('User name field required only alphabet characters');
    }
    else if($("#t4").value=='')
    {
      alert('Please enter Password');
    }
    else if($("#t5").value=='')
    {
      alert('Enter Confirm Password');
    }
    else if(!/^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-])/.test($("#t5").value))
    {
      alert ('Upper case, Lower case, Special character and Numeric letter are required in Password filed');
    }
    else if($("#t4").value != $("#t5").value)
    {
      alert ('Password not Matched');
    }
    else if($("#t5").value.length < 6)
    {
      alert ('Password minimum length is 6');
    }
    else if($("#t5").value.length > 12)
    {
      alert ('Password max length is 12');
    }
    else
    {
               alert('Thank You for Login & You are Redirecting to Campuslife Website');
         // Redirecting to other page or webste code.
         window.location = "http://www.campuslife.co.in";
    }
  }
  function clearFunc()
  {
    document.getElementById("#t1").value="";
    $("#t2").value="";
    $("#t3").value="";
    $("#t4").value="";
    $("#t5").value="";
    
  }
